# -*- coding: utf-8 -*-
"""
Created on Tue Feb  1 11:30:17 2022

@author: Semir
"""
import random
from sys import exit
import rastergrid



class Agent:
    
    "defining all the agents, applying characteristics and coordinate start point set age of agents at 0,store starts at 0"
    def __init__ (self,agents,environment,ia,td_ys,td_xs, y, x,sex=None):
        self.id = ia
        self.environment = environment
        self.age = 0
        self.store = random.randint(0,20)
        self.agents = agents
        self.status = True
        self.sex = sex
        # self.x = random.randint(0,300)
        # self.y = random.randint(0,300z)


        "using the web scraping, if there are values unknown or missing it will be classed as None, If it is None a Random Number will be assigned."
        
        if (x == None):
            self.x = random.randint(0,300)
        else:
            self.x = x 
        if (y == None):
            self.y = random.randint(0,300)
        else:
            self.y = y

      
        "Defines the sex of agent from value initial starting class as None into Male or Female,"
        
        if sex is None:
            self.sex = random.choice(['male','female'])
        else:
            self.sex = sex
        
    # def mate(self,neighbourhood):
    #     for agent in self.agents:
    #         if self.id != agent.id:
               
    #             distance = self.distance_between(agent) 
    #             "If distance is less than or equal to the neighbourhood"
    #             if distance <= neighbourhood:   
                    
         

            
#         def is_dead(self,max_age=100):
#"""Checks if age has reached the maximum age (integer, default 100) and returns a bool answer."""
# 		if type(max_age) != int:
# 			raise TypeError("max_age must be an integer.")
# 		return (self._age >= max_age)       
    # def age(self):
    #     self.increase_age()
        
        "increase age by 1 until reaching 80 at which point agent classed as dead (false status)"
    def increase_age(self):
        self.age = (self.age+1)
        if self.age >= 70:
            self.status = False
            
    "move the agent based upon the set environment sequence up to 300" 
    def move(self):
        if  random.random() <0.5:
            self.x=(self.x+1) %300
        else:
            self.x=(self.x-1) %300
        if  random.random() <0.5:
            self.y=(self.y+1) %300
        else:
            self.y=(self.y-1) %300
        self.store -= 5

    
            
    # def move_grave(self):
    #     self.x = random.randint(310,360)
    #     self.y = random.randint(310,360)
            
        "eat the environment by 10" 

    def eat(self): # eating 10
        
        if self.environment[self.y][self.x] > 10:
            self.environment[self.y][self.x] -= 10
            self.store += 10
    
    "Removes the store and increase that xy position on the environment by 50" 

    def poo(self): #Poo 100
        if self.store >= 200:
            self.store-=50
            self.environment[self.y][self.x]+= 50
        
        if self.store >= 150:
            self.status = False
                

    
    "calculate distance between self and other agents "
    def distance_between(self,agent):    
        return (((self.x - agent.x)**2) + ((self.y - agent.y)**2))**0.5 
    
    
    "share with agents, if self then do not share use distance and share equally"
                    
                    
    
    def share_with_neighbours(self,neighbourhood):
        """
        

        Parameters
        ----------
        neighbourhood : TYPE
            DESCRIPTION.

        Returns
        -------
        None.

        """
        
        for agent in self.agents:
            if self.id != agent.id:
               
                distance = self.distance_between(agent) 
                "If distance is less than or equal to the neighbourhood"
     
                if distance <= neighbourhood:    
                   #print("sharing",self.id,agent.id)  
                   sum = self.store + agent.store
                   avg = sum /2
                   self.store = avg
                   agent.store = avg
                   return
                   
    
       
                   
      
       # def mate(self,neighbourhood):
       #     for agent in self.agents:
       #         if self.id != agent.id:
                  
       #             distance = self.distance_between(agent) 
       #             "If distance is less than or equal to the neighbourhood"
        
       #             if distance <= neighbourhood:    
       #                #print("sharing",self.id,agent.id)              

                           

         
    "When printing these will be listed this is the defintiion of the string at the start of the code"
    def __str__(self):
        return "id" + str(self.id) + ", x = " + str(self.x) + ", y = " +str(self.y)+ ", store = "+str(self.store)+ ", age = "+str(self.age)+ ", sex = "+str(self.sex)
     
    